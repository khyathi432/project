from flask import Flask, render_template, request, session, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = "secret123"


def start_game(level):
    if level == "easy":
        max_num = 10
        chances = 3
    elif level == "medium":
        max_num = 50
        chances = 5
    else:
        max_num = 100
        chances = 7

    session["number"] = random.randint(1, max_num)
    session["chances"] = chances
    session["max_num"] = max_num
    session["game_over"] = False
    session["message"] = ""


@app.route("/", methods=["GET", "POST"])
def index():

    if "high_score" not in session:
        session["high_score"] = 0

    if "number" not in session:
        start_game("easy")
        session["score"] = 0

    if request.method == "POST":
        if "level" in request.form:
            # Level selected → restart game
            level = request.form["level"]
            start_game(level)
            return redirect(url_for("index"))

        if not session["game_over"]:
            guess = int(request.form["guess"])
            number = session["number"]

            if guess == number:
                session["message"] = f"🎉 Correct! Number was {number}"
                session["score"] += 10
                session["game_over"] = True

                if session["score"] > session["high_score"]:
                    session["high_score"] = session["score"]

            else:
                session["chances"] -= 1

                if session["chances"] == 0:
                    session["message"] = f"😢 Game Over! Number was {number}"
                    session["score"] -= 5
                    session["game_over"] = True
                elif guess < number:
                    session["message"] = "🔼 Too Low!"
                else:
                    session["message"] = "🔽 Too High!"

    return render_template(
        "index.html",
        message=session["message"],
        score=session["score"],
        high_score=session["high_score"],
        chances=session["chances"],
        max_num=session["max_num"],
        game_over=session["game_over"]
    )


@app.route("/restart")
def restart():
    session.pop("number", None)
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)