// Optional: small UI improvement
document.querySelector("form").addEventListener("submit", () => {
    console.log("Guess submitted");
});
console.log("Game Loaded");